# GA4 Product Analytics

Dự án SQL phân tích phễu mua hàng theo phiên. **Trang Notion là bản báo cáo chính**, gồm các chỉnh sửa bổ sung của bạn. File `GA4_Product_Analytics.md` là nội dung gốc trước khi trang Notion được chỉnh sửa.

Bộ truy vấn đã chạy thành công trên BigQuery Sandbox ngày 29/10/2026, gồm chế độ strict và kiểm tra độ nhạy weak. Dữ liệu là GA4 mẫu đã làm nhiễu của Google. Xem kết quả và giới hạn tại [báo cáo thực nghiệm](docs/KET_QUA_BIGQUERY_2026-10-29.md). Các ghi chú trước ngày chạy trong file nội dung Notion gốc chỉ là lịch sử.

Đọc [hướng dẫn chạy](docs/HUONG_DAN_CHAY.md) và [nhật ký kiểm tra](docs/VALIDATION_2026-10-29.md).

- `sql/00_profile.sql`: kiểm tra schema và thống kê hai ngày mẫu.
- `sql/00_estimate_scan.sql`: SELECT dùng để dry-run ước tính phần đọc dữ liệu nguồn.
- `sql/01_ga4_funnel.sql`: pipeline đầy đủ, gồm 08b theo thiết bị; chạy trong một script.
- `sql/02_optional_persist.sql`: khối lưu bảng tùy chọn, nối vào cuối script chính; dùng tên bảng mới.
- `tests/`: kiểm thử logic và CSV giả lập, có nhãn rõ ràng.
- `scripts/build_report.py`: kiểm tra CSV và dựng báo cáo, biểu đồ SVG.
- `results/bigquery_strict`, `results/bigquery_weak`: kết quả BigQuery JSON và CSV; chỉ chứa bảng tổng hợp.
- `reports/bigquery_2026-10-29`: báo cáo và biểu đồ từ kết quả BigQuery.

Chạy offline với Python 3.9+, không cần thư viện ngoài:

```powershell
python -m unittest discover -s tests -v
python scripts/build_report.py --input tests/fixtures/strict --weak tests/fixtures/weak --mode fixture --output demo_report
```

Các số trong `tests/fixtures` và `demo_report` là **dữ liệu giả lập**, không phải kết quả từ GA4.

Nguồn: [Google Analytics sample ecommerce dataset](https://developers.google.com/analytics/bigquery/web-ecommerce-demo-dataset). Dữ liệu đã làm nhiễu và có thể không nhất quán. Cần Google Cloud project có BigQuery để thực thi trên nguồn; Sandbox có thể dùng cho khám phá theo giới hạn dịch vụ.
