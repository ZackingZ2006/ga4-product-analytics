# GA4 Product Analytics — Phân tích phễu mua hàng bằng SQL

**Portfolio SQL • Product Analytics • BigQuery / GoogleSQL • Phiên bản 28/10/2026**

**TRẠNG THÁI:** Đã soạn bộ SQL, định nghĩa KPI, quy tắc chất lượng và kiểm thử logic cục bộ. 13 bài kiểm thử đã qua, gồm đối chiếu 500 luồng sự kiện ở hai chế độ thứ tự. **Chưa chạy trên dữ liệu GA4 gốc bằng BigQuery; chưa có KPI, biểu đồ kết quả hoặc tác động kinh doanh được xác nhận.**

Dự án phân tích hành vi trước khi đặt hàng: xem sản phẩm → thêm giỏ → bắt đầu thanh toán → mua hàng. Phần SQL là sản phẩm chính; dashboard chỉ được xây sau khi đối soát kết quả. Customer 360 hiện có tập trung vào giao dịch và khách đã mua; dự án này bổ sung xử lý log sự kiện và hành trình chuyển đổi.

## 1. Bối cảnh và câu hỏi kinh doanh

Giả định vai trò: Data Analyst / Data Scientist hỗ trợ đội Product của một website thương mại điện tử. Website cần biết người dùng rời hành trình ở bước nào và nhóm thiết bị nào cần kiểm tra trải nghiệm trước. Đây là tình huống phân tích portfolio, không phải một dự án khách hàng thực tế đã triển khai.

- Có bao nhiêu phiên đủ điều kiện và bao nhiêu phiên hoàn thành từng bước của phễu?
- Bước nào mất nhiều phiên nhất theo số tuyệt đối và tỷ lệ?
- Mobile, desktop và tablet khác nhau thế nào về chuyển đổi? Mẫu có đủ lớn để so sánh?
- Nhóm người dùng theo nguồn thu hút ban đầu khác nhau thế nào? Không nhầm với attribution của phiên hiện tại.
- Bao lâu sau lần xem sản phẩm thì các phiên hoàn tất phễu ghi nhận mua hàng?
- Kết quả thay đổi ra sao khi cho phép các bước có cùng timestamp?
- Dữ liệu thiếu, mã giao dịch lặp và phiên bị cắt biên có thể làm KPI sai đến mức nào?

## 2. Nguồn dữ liệu và phạm vi

Nguồn chính thức: [Google Analytics ecommerce sample dataset](https://developers.google.com/analytics/bigquery/web-ecommerce-demo-dataset). Dataset công khai `bigquery-public-data.ga4_obfuscated_sample_ecommerce`, bảng ngày `events_*`, phạm vi 01/11/2020–31/01/2021. Google đã làm nhiễu dữ liệu; có placeholder, NULL và hạn chế nhất quán nội bộ. Không gọi đây là log nguyên vẹn hoặc so số liệu trực tiếp với tài khoản GA Demo.

| Phạm vi | Quy ước |
| --- | --- |
| Nguồn quét | 92 bảng ngày, 01/11/2020–31/01/2021 |
| Cohort phân tích | Phiên có ngày sự kiện đầu quan sát từ 02/11/2020–30/01/2021 |
| Vùng đệm | Loại phiên chạm 01/11/2020 hoặc 31/01/2021 để hạn chế cắt biên |
| Cấp dữ liệu chính | Một dòng / cặp user_pseudo_id và ga_session_id |
| Tiền tệ | USD từ ecommerce.purchase_revenue_in_usd; không tự cộng các tiền tệ địa phương |
| Đếm người dùng | Pseudonymous identifier quan sát được, không đồng nhất với số người thật |
| Kết quả hiện tại | Chưa có kết quả BigQuery trên dataset nguồn |

Phạm vi ba tháng phù hợp bài phễu; không dùng để khẳng định mùa vụ dài hạn, retention nhiều năm hoặc hiệu quả CRM. Cách dùng vùng đệm giảm rủi ro cắt biên nhưng không chứng minh tracking đầy đủ.

## 3. Data dictionary tối thiểu

| Trường | Ý nghĩa / lưu ý |
| --- | --- |
| event_date | Ngày theo timezone đăng ký của property; giữ làm ngày báo cáo |
| event_timestamp | Microsecond UTC; dùng kiểm tra thứ tự bước |
| event_name | view_item, add_to_cart, begin_checkout, purchase và các sự kiện khác |
| user_pseudo_id | Định danh giả danh; NULL / placeholder không được ép thành một khách chung |
| event_params | Mảng key/value; trích ga_session_id bằng subquery trước khi xử lý items |
| device.category / geo.country | Nhóm thiết bị và quốc gia; giữ Unknown / Mixed thay vì tự suy đoán |
| traffic_source.source / medium | Nguồn thu hút người dùng lần đầu, không phải nguồn của phiên hiện tại |
| ecommerce.transaction_id | Khóa giao dịch giả định duy nhất cho một cửa hàng; kiểm tra xung đột trước khi dùng |
| ecommerce.purchase_revenue_in_usd | Số tiền purchase được ghi nhận; không phải lợi nhuận hay doanh thu sau hoàn tiền |
| items | Mảng sản phẩm; UNNEST ở mô hình riêng, không nhân bản chỉ số cấp phiên / đơn |

## 4. Kiến trúc SQL và grain

Luồng triển khai: `events_* → stg_events → valid_events → fct_sessions → mart_session_funnel`. Nhánh giao dịch riêng: `stg_events → order_quality → canonical_orders → fct_orders → orders_by_session`; chỉ ghép sau khi đã tổng hợp về cấp phiên.

| Mô hình | Một dòng đại diện cho | Điều kiện chính |
| --- | --- | --- |
| stg_events | Một dòng sự kiện nguồn | Giữ sự kiện lặp vì không có event_id đáng tin |
| valid_events | Một sự kiện có khóa phiên hợp lệ | User không thiếu, session ID dương, đúng một key ga_session_id |
| fct_sessions | Một phiên quan sát | Đúng cohort, không chạm biên; dimensions xung đột gán Mixed |
| canonical_orders | Một transaction_id | Bản purchase quan sát sớm nhất; nhận diện xung đột |
| fct_orders | Một giao dịch không bị quarantine | Không nhiều user, không nhiều số tiền khác nhau, không âm / vô hạn |
| orders_by_session | Một phiên có giao dịch hợp lệ | Tổng hợp đơn trước khi JOIN vào session mart |
| mart_session_funnel | Một phiên đủ điều kiện | Có cờ các bước theo thời gian và metric giao dịch riêng |

## 5. Hợp đồng đo lường — định nghĩa trước khi chạy

| KPI | Tử số / mẫu số hoặc cách tính |
| --- | --- |
| Eligible sessions | COUNT(*) trên mart_session_funnel; một khóa phiên một dòng |
| Recorded purchase sessions | Phiên có ít nhất một purchase event, kể cả khi thiếu transaction_id |
| Verified-order session rate | Phiên có ≥1 giao dịch hợp lệ / toàn bộ phiên đủ điều kiện |
| View-to-purchase rate | Phiên hoàn tất chuỗi bước đúng thứ tự / phiên có view_item |
| Step conversion | Phiên đạt bước hiện tại / phiên đạt bước trước trong cùng chuỗi |
| Drop-off | Phiên đạt bước trước trừ phiên đạt bước tiếp; báo cả số lượng và tỷ lệ |
| Recorded revenue USD | Tổng số tiền được biết từ giao dịch hợp lệ gắn được vào cohort phiên |
| AOV known amount | Doanh thu biết được / số đơn biết số tiền; kèm amount completeness |
| Time to purchase | purchase_ts − view_ts, chỉ trên phiên hoàn tất chuỗi; báo median và p90 |
| 7-day conversion | SUM(completions) / SUM(entrants) trong 7 ngày, không AVG các tỷ lệ ngày |

Ba cách đếm purchase ở trên có thể khác nhau và phải được giữ riêng. Một purchase event không tự chứng minh có một đơn hợp lệ; một đơn hợp lệ có thể không đi qua đủ các bước được tracking. Các ngày đầu chưa đủ cửa sổ 7 ngày có cột calendar_days_in_window để nhận diện.

## 6. Quy tắc phễu và các lỗi dễ mắc

- Phễu cấp phiên, bắt đầu ở view_item. Cho phép sự kiện khác xen giữa các bước; không ghép hành vi qua hai phiên.
- Chọn lần cart đầu tiên SAU view, rồi checkout đầu tiên SAU cart và purchase đầu tiên SAU checkout. Không lấy MIN từng event độc lập rồi so sánh.
- Một lượt xem sản phẩm A và thêm giỏ sản phẩm B vẫn thuộc phễu cấp phiên. Chưa gọi đây là chuyển đổi cùng SKU.
- Chế độ chính yêu cầu timestamp tăng nghiêm ngặt. Timestamp bằng nhau có thứ tự chưa biết; chạy lại chế độ >= để phân tích độ nhạy, không khẳng định đó là chuyển đổi được phục hồi.
- Dataset cũ thiếu các batch ordering fields mới. Không bịa cột để phân giải đồng thời.
- Không JOIN event_params và items bằng hai CROSS JOIN độc lập rồi SUM doanh thu: sẽ gây fan-out.
- Không gộp mọi event thiếu user/session thành một khóa Unknown; quarantine và báo tỷ trọng bị loại.
- transaction_id lặp cùng người / cùng tiền được chuẩn hóa về một đơn; khác người hoặc khác tiền được đưa vào quarantine.
- Không thay số tiền thiếu bằng 0. Đơn vẫn được đếm khi đủ điều kiện nhưng phải báo độ đầy đủ số tiền.
- traffic_source là first-user acquisition. Không gọi bảng này là hiệu quả quảng cáo của phiên, CAC hoặc ROAS.

## 7. Kiểm chứng và trạng thái thực thi

| Hạng mục | Trạng thái | Bằng chứng / giới hạn |
| --- | --- | --- |
| Kiểm thử logic cục bộ | Đã chạy: 13/13 qua | Python unittest + SQLite, kết quả trong docs/local_test_results.txt |
| Đối chiếu ngẫu nhiên | Đã chạy | 500 luồng sự kiện, đối chiếu SQL SQLite với Python độc lập, cả > và >= |
| Core funnel SQL | Đã kiểm thử hành vi qua bản dịch SQLite | Không đồng nghĩa BigQuery đã parse hoặc thực thi thành công |
| BigQuery schema preflight | Chờ chạy | sql/00_profile.sql: kiểm tra cột và hai ngày mẫu |
| BigQuery quality assertions | Chờ chạy | Có trong mục 06 của sql/01_ga4_funnel.sql |
| KPI và insight dữ liệu GA4 | Chưa có | Không điền số giả hoặc lấy số từ portfolio của người khác |
| Tác động kinh doanh / A/B test | Chưa đo | Dataset không có thí nghiệm ngẫu nhiên phục vụ kết luận nhân quả |

Các kiểm thử đã chạy gồm: chuỗi hợp lệ, cart sớm sai thứ tự rồi cart hợp lệ, purchase thiếu bước, sự kiện lặp, cùng user khác session, khác user trùng session ID, timestamp bằng nhau, thiếu identity, trùng transaction, transaction xung đột, thiếu amount và xử lý vùng đệm. Đây là kiểm thử logic, không phải kết quả kinh doanh của Google Merchandise Store.

## 8. Hướng dẫn chạy khi chưa có BigQuery

- Đăng nhập Google Cloud bằng tài khoản của bạn, tạo một project và dùng BigQuery Sandbox theo tài liệu chính thức. Chưa cần bật billing cho bước khám phá trong giới hạn Sandbox.
- Mở BigQuery → SQL workspace. Dùng GoogleSQL, không dùng Legacy SQL hoặc SQL Server cho các script này.
- Chạy sql/00_profile.sql trước; đối chiếu schema và thống kê hai ngày mẫu. Nếu schema không khớp, sửa có ghi nhận thay vì bỏ qua lỗi.
- Mở sql/01_ga4_funnel.sql và chạy nguyên file trong một script: các mục sau phụ thuộc TEMP TABLE ở đầu. Chạy lẻ mục sau sẽ thiếu bảng tạm.
- Script chính có bộ lọc suffix hằng 01/11/2020–31/01/2021 và quét cả nguồn một lần. Đổi cohort_start/end KHÔNG giảm lượng quét nguồn. Xem ước lượng / execution details; nếu chưa rõ lượng quét, dừng trước khi chạy toàn bộ.
- Xuất các result set 02–15 thành CSV; lưu ngày chạy, phiên bản SQL, tham số, job ID, bytes processed và warnings.
- Chạy lại strict_order = FALSE và so sánh phễu mục 08. Giữ bản chính strict_order = TRUE.
- Chỉ cập nhật phần kết quả trên trang sau khi quality assertions qua và số đơn / doanh thu đối soát đúng.

Tài liệu: [BigQuery Sandbox](https://cloud.google.com/bigquery/docs/sandbox). Việc tạo tài khoản/project và chấp nhận điều khoản do chủ tài khoản thực hiện. Trang này chưa tạo project Google Cloud hoặc bật billing.

## 9. Bảng kết quả — chờ thực thi dữ liệu nguồn

| Chỉ số / đầu ra | Giá trị hiện tại | Truy vấn cung cấp |
| --- | --- | --- |
| Phiên và user hợp lệ | Chưa chạy BigQuery | 03_session_scope, 07_kpi_overview |
| Số phiên từng bước / drop-off | Chưa chạy BigQuery | 08_funnel_steps |
| Thiết bị cần ưu tiên điều tra | Chưa kết luận | 09_device_conversion |
| Nguồn thu hút người dùng lần đầu | Chưa kết luận | 10_first_user_acquisition |
| Chuyển đổi theo ngày / 7 ngày | Chưa chạy BigQuery | 11_daily_trend |
| Thời gian tới purchase | Chưa chạy BigQuery | 12_time_to_purchase |
| Sản phẩm có nhiều phiên xem / thêm giỏ | Chưa chạy BigQuery | 13_product_exposure |
| Tỷ lệ timestamp đồng thời / độ nhạy | Chưa chạy BigQuery | 14_timestamp_ties + rerun strict_order = FALSE |

Mẫu viết insight sau khi có kết quả: “Trong N phiên có xem sản phẩm, bước X còn Y phiên, tương đương Z% chuyển tiếp. Nhóm A thấp hơn nhóm B khoảng D điểm phần trăm; cần kiểm tra composition và tracking trước khi quy nguyên nhân cho giao diện.” N, Y, Z và D phải lấy từ kết quả chạy đã lưu; chưa có giá trị số trong phiên bản này.

## 10. Đề xuất hành động theo điều kiện

| Dấu hiệu sau khi chạy | Hành động kiểm tra | Cách đo tiếp |
| --- | --- | --- |
| Mobile rơi mạnh ở checkout, đủ mẫu | Rà tốc độ trang, form và lỗi thanh toán; tách theo sản phẩm / quốc gia | Thiết kế thử nghiệm ngẫu nhiên nếu có quyền triển khai; theo dõi conversion và lỗi |
| view → cart thấp ở một nhóm sản phẩm | Kiểm tra chất lượng trang sản phẩm, giá và tình trạng hàng | Kiểm tra log / dữ liệu bổ sung; chưa suy luận thiếu hàng từ GA4 đơn lẻ |
| Nhiều purchase thiếu ID hoặc xung đột amount | Ưu tiên sửa tracking và hợp đồng dữ liệu | Theo dõi tỷ lệ ID hợp lệ, trùng ID và độ đầy đủ amount |
| Kết quả nhạy mạnh với timestamp bằng nhau | Hạn chế kết luận về điểm rơi; đề xuất bổ sung thứ tự sự kiện | Báo cả hai chính sách và tỷ lệ ambiguous groups |
| Chênh lệch nguồn thu hút cao | Kiểm tra mix thiết bị / quốc gia và định nghĩa acquisition | Không tối ưu ngân sách chỉ từ tương quan quan sát |

## 11. SQL — preflight và script triển khai

File chạy: `sql/00_profile.sql` rồi `sql/01_ga4_funnel.sql`. Các khối dưới đây là nội dung đầy đủ để tham khảo; với script chính, ghép theo đúng thứ tự hoặc dùng nguyên file. **Mã chưa được chạy / dry-run trên BigQuery.**

### 11.0 — Kiểm tra schema và hai ngày mẫu

```sql
-- GoogleSQL / BigQuery | Read-only preflight. NOT yet executed on BigQuery.
-- A two-day source sample avoids a blind full-range scan during initial checks.
SELECT table_name, field_path, data_type
FROM `bigquery-public-data.ga4_obfuscated_sample_ecommerce.INFORMATION_SCHEMA.COLUMN_FIELD_PATHS`
WHERE table_name = 'events_20201101'
  AND (field_path IN ('event_date','event_timestamp','event_name','user_pseudo_id',
                     'event_params.key','event_params.value.int_value',
                     'device.category','geo.country','traffic_source.source',
                     'traffic_source.medium','ecommerce.transaction_id',
                     'ecommerce.purchase_revenue_in_usd','items.item_id'))
ORDER BY field_path;

SELECT event_name, COUNT(*) AS event_rows,
  COUNT(DISTINCT user_pseudo_id) AS pseudonymous_users,
  COUNTIF(user_pseudo_id IS NULL) AS rows_without_user
FROM `bigquery-public-data.ga4_obfuscated_sample_ecommerce.events_*`
WHERE _TABLE_SUFFIX BETWEEN '20201102' AND '20201103'
GROUP BY event_name ORDER BY event_rows DESC;

-- Keys that repeat inside one event need investigation before scalar extraction.
SELECT COUNT(*) AS rows_with_duplicate_session_key
FROM `bigquery-public-data.ga4_obfuscated_sample_ecommerce.events_*`
WHERE _TABLE_SUFFIX BETWEEN '20201102' AND '20201103'
  AND (SELECT COUNT(*) FROM UNNEST(event_params) WHERE key='ga_session_id') > 1;
```

### 11.A — Cấu hình và giới hạn nguồn quét

```sql
-- GA4 Product Analytics | GoogleSQL / BigQuery
-- STATUS: authored + logic reviewed; NOT executed on the public BigQuery dataset.
-- Run as ONE multi-statement script. TEMP tables do not modify source data.
-- Run 00_profile.sql first. This main script scans all 92 source shards once.
-- Changing cohort_start/end does NOT reduce that scan; inspect bytes before run.
-- Source: bigquery-public-data.ga4_obfuscated_sample_ecommerce.events_*

DECLARE cohort_start DATE DEFAULT DATE '2020-11-02';
DECLARE cohort_end DATE DEFAULT DATE '2021-01-30';
DECLARE strict_order BOOL DEFAULT TRUE;
ASSERT cohort_start >= DATE '2020-11-02'
   AND cohort_end <= DATE '2021-01-30'
   AND cohort_start <= cohort_end AS 'Cohort outside guarded source window';
```

### SQL 01. STAGING: keep event rows, including repeats. There is no reliable event_id.

```sql
-- 01. STAGING: keep event rows, including repeats. There is no reliable event_id.
-- Extract scalar parameters before UNNEST(items); never cross-join two arrays.
-- Duplicate ga_session_id keys are quarantined, not resolved arbitrarily.
CREATE TEMP TABLE stg_events AS
WITH extracted AS (
  SELECT
    PARSE_DATE('%Y%m%d', event_date) AS property_event_date,
    event_timestamp AS event_ts_us,
    event_name,
    NULLIF(TRIM(user_pseudo_id), '') AS user_pseudo_id,
    (SELECT MAX(value.int_value) FROM UNNEST(event_params)
     WHERE key = 'ga_session_id') AS ga_session_id,
    (SELECT COUNT(*) FROM UNNEST(event_params)
     WHERE key = 'ga_session_id') AS session_param_count,
    COALESCE(NULLIF(device.category, ''), 'Unknown') AS device_category,
    COALESCE(NULLIF(geo.country, ''), 'Unknown') AS country,
    COALESCE(NULLIF(traffic_source.source, ''), 'Unknown') AS first_user_source,
    COALESCE(NULLIF(traffic_source.medium, ''), 'Unknown') AS first_user_medium,
    CASE WHEN TRIM(ecommerce.transaction_id) IN ('', '(not set)', '<Other>')
         THEN NULL ELSE TRIM(ecommerce.transaction_id) END AS transaction_id,
    ecommerce.purchase_revenue_in_usd AS purchase_revenue_usd,
    items
  FROM `bigquery-public-data.ga4_obfuscated_sample_ecommerce.events_*`
  -- Constant suffix bounds prune daily shards. Both edges are observation buffers.
  WHERE _TABLE_SUFFIX BETWEEN '20201101' AND '20210131'
)
SELECT *,
  CASE WHEN user_pseudo_id IS NOT NULL
         AND user_pseudo_id NOT IN ('(not set)', '<Other>')
         AND session_param_count = 1 AND ga_session_id > 0
       THEN TO_JSON_STRING(STRUCT(user_pseudo_id AS uid, ga_session_id AS sid))
       ELSE NULL END AS session_key
FROM extracted;
```

### SQL 02. DATA QUALITY: report excluded events, duplicate parameter keys and amounts.

```sql
-- 02. DATA QUALITY: report excluded events, duplicate parameter keys and amounts.
SELECT '02_data_quality' AS result_set,
  COUNT(*) AS source_event_rows,
  COUNTIF(session_key IS NULL) AS events_without_usable_session,
  COUNTIF(session_param_count > 1) AS events_with_duplicate_session_parameter,
  COUNTIF(event_name = 'purchase') AS recorded_purchase_events,
  COUNTIF(event_name = 'purchase' AND transaction_id IS NULL) AS purchases_without_transaction_id,
  COUNTIF(event_name = 'purchase' AND purchase_revenue_usd IS NULL) AS purchases_without_usd_amount,
  COUNTIF(event_name = 'purchase' AND purchase_revenue_usd < 0) AS purchases_with_negative_amount,
  COUNTIF(purchase_revenue_usd IS NOT NULL
          AND (IS_NAN(purchase_revenue_usd) OR IS_INF(purchase_revenue_usd))) AS nonfinite_amounts
FROM stg_events;

CREATE TEMP TABLE valid_events AS
SELECT * FROM stg_events WHERE session_key IS NOT NULL;
```

### SQL 03. SESSION MART: grain = (user_pseudo_id, ga_session_id), not session_id alone.

```sql
-- 03. SESSION MART: grain = (user_pseudo_id, ga_session_id), not session_id alone.
-- event_date uses the property's registered timezone; timestamp ordering uses UTC.
CREATE TEMP TABLE session_candidates AS
SELECT
  session_key,
  ANY_VALUE(user_pseudo_id) AS user_pseudo_id,
  ANY_VALUE(ga_session_id) AS ga_session_id,
  MIN(property_event_date) AS cohort_date,
  MIN(event_ts_us) AS first_observed_ts_us,
  MAX(event_ts_us) AS last_observed_ts_us,
  COUNT(*) AS event_rows,
  COUNTIF(event_name = 'purchase') > 0 AS has_purchase_event,
  COUNTIF(property_event_date IN (DATE '2020-11-01', DATE '2021-01-31')) > 0 AS touches_source_edge,
  COUNTIF(event_name = 'session_start') > 0 AS has_session_start_event,
  COUNT(DISTINCT device_category) > 1 AS device_conflict,
  COUNT(DISTINCT country) > 1 AS country_conflict,
  COUNT(DISTINCT first_user_source) > 1 AS first_user_source_conflict,
  CASE WHEN COUNT(DISTINCT device_category) = 1
       THEN MIN(device_category) ELSE 'Mixed' END AS device_category,
  CASE WHEN COUNT(DISTINCT country) = 1
       THEN MIN(country) ELSE 'Mixed' END AS country,
  CASE WHEN COUNT(DISTINCT first_user_source) = 1
       THEN MIN(first_user_source) ELSE 'Mixed' END AS first_user_source,
  CASE WHEN COUNT(DISTINCT first_user_medium) = 1
       THEN MIN(first_user_medium) ELSE 'Mixed' END AS first_user_medium
FROM valid_events
GROUP BY session_key;

CREATE TEMP TABLE fct_sessions AS
SELECT * FROM session_candidates
WHERE cohort_date BETWEEN cohort_start AND cohort_end
  AND NOT touches_source_edge;

SELECT '03_session_scope' AS result_set,
  COUNT(*) AS candidate_sessions,
  COUNTIF(touches_source_edge) AS sessions_touching_source_boundary,
  COUNTIF(cohort_date BETWEEN cohort_start AND cohort_end
          AND NOT touches_source_edge) AS included_sessions,
  COUNTIF(NOT has_session_start_event) AS candidates_missing_session_start,
  COUNTIF(device_conflict OR country_conflict OR first_user_source_conflict) AS candidates_with_dimension_conflict
FROM session_candidates;
```

### SQL 04. ORDER MART: transaction_id is assumed globally unique for this one store.

```sql
-- 04. ORDER MART: transaction_id is assumed globally unique for this one store.
-- A repeated transaction is not a second order. Conflicting user/amount -> quarantine.
-- Missing amount does not become 0; missing-id purchases stay in funnel quality stats.
CREATE TEMP TABLE order_quality AS
SELECT transaction_id,
  COUNT(*) AS purchase_event_rows,
  COUNT(DISTINCT user_pseudo_id) AS observed_users,
  COUNT(DISTINCT ROUND(purchase_revenue_usd, 2)) AS observed_usd_amounts,
  COUNTIF(purchase_revenue_usd < 0) AS negative_amount_rows,
  COUNTIF(purchase_revenue_usd IS NOT NULL
          AND (IS_NAN(purchase_revenue_usd) OR IS_INF(purchase_revenue_usd))) AS nonfinite_amount_rows
FROM stg_events
WHERE event_name = 'purchase' AND transaction_id IS NOT NULL
GROUP BY transaction_id;

CREATE TEMP TABLE canonical_orders AS
SELECT e.*, q.purchase_event_rows,
  q.observed_users > 1 OR q.observed_usd_amounts > 1
    OR q.negative_amount_rows > 0 OR q.nonfinite_amount_rows > 0 AS quarantined
FROM stg_events AS e
JOIN order_quality AS q USING (transaction_id)
WHERE e.event_name = 'purchase'
QUALIFY ROW_NUMBER() OVER (
  PARTITION BY transaction_id
  ORDER BY event_ts_us, COALESCE(session_key, ''),
           COALESCE(user_pseudo_id, ''), purchase_revenue_usd
) = 1;

CREATE TEMP TABLE fct_orders AS
SELECT * FROM canonical_orders WHERE NOT quarantined;

CREATE TEMP TABLE orders_by_session AS
SELECT session_key,
  COUNT(*) AS verified_orders,
  COUNTIF(purchase_revenue_usd IS NOT NULL) AS orders_with_amount,
  SUM(purchase_revenue_usd) AS recorded_revenue_usd
FROM fct_orders
WHERE session_key IS NOT NULL
GROUP BY session_key;

SELECT '04_order_quality' AS result_set,
  COUNT(*) AS distinct_transaction_ids,
  COUNTIF(purchase_event_rows > 1) AS repeated_transaction_ids,
  SUM(purchase_event_rows - 1) AS repeated_purchase_rows,
  COUNTIF(quarantined) AS quarantined_transactions,
  COUNTIF(NOT quarantined AND session_key IS NULL) AS unassigned_valid_transactions,
  COUNTIF(NOT quarantined AND purchase_revenue_usd IS NULL) AS valid_transactions_missing_amount
FROM canonical_orders;
```

### SQL 05. ORDERED FUNNEL. Open between intermediate events; closed at view_item entry.

```sql
-- 05. ORDERED FUNNEL. Open between intermediate events; closed at view_item entry.
-- Grain = one session, not one user, item or order. Different products may occur.
-- Strict mode uses >. Equal timestamps have unknown order in this old sample.
-- This sample lacks batch_page_id / batch_ordering_id / batch_event_index.
CREATE TEMP TABLE step_view AS
SELECT s.session_key, MIN(IF(e.event_name = 'view_item', e.event_ts_us, NULL)) AS view_ts
FROM fct_sessions AS s
JOIN valid_events AS e USING (session_key)
GROUP BY s.session_key;

CREATE TEMP TABLE step_cart AS
SELECT v.session_key, v.view_ts,
  MIN(IF(e.event_name = 'add_to_cart'
         AND (e.event_ts_us > v.view_ts OR (NOT strict_order AND e.event_ts_us = v.view_ts)),
         e.event_ts_us, NULL)) AS cart_ts
FROM step_view AS v
LEFT JOIN valid_events AS e USING (session_key)
GROUP BY v.session_key, v.view_ts;

CREATE TEMP TABLE step_checkout AS
SELECT c.session_key, c.view_ts, c.cart_ts,
  MIN(IF(e.event_name = 'begin_checkout'
         AND (e.event_ts_us > c.cart_ts OR (NOT strict_order AND e.event_ts_us = c.cart_ts)),
         e.event_ts_us, NULL)) AS checkout_ts
FROM step_cart AS c
LEFT JOIN valid_events AS e USING (session_key)
GROUP BY c.session_key, c.view_ts, c.cart_ts;

CREATE TEMP TABLE step_purchase AS
SELECT c.session_key, c.view_ts, c.cart_ts, c.checkout_ts,
  MIN(IF(e.event_name = 'purchase'
         AND (e.event_ts_us > c.checkout_ts OR (NOT strict_order AND e.event_ts_us = c.checkout_ts)),
         e.event_ts_us, NULL)) AS purchase_ts
FROM step_checkout AS c
LEFT JOIN valid_events AS e USING (session_key)
GROUP BY c.session_key, c.view_ts, c.cart_ts, c.checkout_ts;

CREATE TEMP TABLE mart_session_funnel AS
SELECT s.*,
  p.view_ts, p.cart_ts, p.checkout_ts, p.purchase_ts,
  p.view_ts IS NOT NULL AS viewed,
  p.cart_ts IS NOT NULL AS carted_after_view,
  p.checkout_ts IS NOT NULL AS checked_out_after_cart,
  p.purchase_ts IS NOT NULL AS purchased_in_order,
  COALESCE(o.verified_orders, 0) AS verified_orders,
  COALESCE(o.orders_with_amount, 0) AS orders_with_amount,
  o.recorded_revenue_usd,
  SAFE_DIVIDE(p.purchase_ts - p.view_ts, 1000000.0) AS view_to_purchase_seconds
FROM fct_sessions AS s
JOIN step_purchase AS p USING (session_key)
LEFT JOIN orders_by_session AS o USING (session_key);
```

### SQL 06. EXECUTABLE QUALITY CONTRACTS: fail before exporting misleading KPIs.

```sql
-- 06. EXECUTABLE QUALITY CONTRACTS: fail before exporting misleading KPIs.
ASSERT (SELECT COUNT(*) > 0 FROM fct_sessions) AS 'No eligible sessions';
ASSERT (SELECT COUNTIF(viewed) > 0 FROM mart_session_funnel) AS 'No funnel entrants';
ASSERT (SELECT COUNT(*) = COUNT(DISTINCT session_key) FROM fct_sessions)
  AS 'Duplicate session keys';
ASSERT (SELECT COUNT(*) FROM mart_session_funnel) = (SELECT COUNT(*) FROM fct_sessions)
  AS 'Session mart fan-out';
ASSERT (SELECT COUNT(*) = COUNT(DISTINCT transaction_id) FROM fct_orders)
  AS 'Duplicate transaction IDs after canonicalization';
ASSERT (SELECT COUNTIF(carted_after_view AND NOT viewed) = 0 FROM mart_session_funnel)
  AS 'Cart without funnel entry';
ASSERT (SELECT COUNTIF(checked_out_after_cart AND NOT carted_after_view) = 0 FROM mart_session_funnel)
  AS 'Checkout without eligible cart';
ASSERT (SELECT COUNTIF(purchased_in_order AND NOT checked_out_after_cart) = 0 FROM mart_session_funnel)
  AS 'Purchase without eligible checkout';
ASSERT (SELECT COUNTIF(purchased_in_order AND NOT has_purchase_event) = 0 FROM mart_session_funnel)
  AS 'Funnel purchase not observed';
ASSERT (SELECT COALESCE(SUM(verified_orders), 0) FROM mart_session_funnel)
     = (SELECT COUNT(*) FROM fct_orders AS o JOIN fct_sessions AS s USING (session_key))
  AS 'Order reconciliation failed';
ASSERT ABS(
  (SELECT COALESCE(SUM(recorded_revenue_usd), 0) FROM mart_session_funnel)
  - (SELECT COALESCE(SUM(o.purchase_revenue_usd), 0)
     FROM fct_orders AS o JOIN fct_sessions AS s USING (session_key))
) < 0.01 AS 'Revenue reconciliation failed';
```

### SQL 07. KPI OVERVIEW. Source amount is gross recorded purchase revenue, not profit.

```sql
-- 07. KPI OVERVIEW. Source amount is gross recorded purchase revenue, not profit.
SELECT '07_kpi_overview' AS result_set,
  COUNT(*) AS eligible_sessions,
  COUNT(DISTINCT user_pseudo_id) AS pseudonymous_users,
  COUNTIF(has_purchase_event) AS sessions_with_purchase_event,
  COUNTIF(verified_orders > 0) AS sessions_with_verified_order,
  COUNTIF(purchased_in_order) AS strict_funnel_purchase_sessions,
  SAFE_DIVIDE(COUNTIF(verified_orders > 0), COUNT(*)) AS verified_order_session_rate,
  SAFE_DIVIDE(COUNTIF(purchased_in_order), COUNTIF(viewed)) AS view_to_purchase_rate,
  SUM(verified_orders) AS verified_orders,
  SUM(orders_with_amount) AS orders_with_known_amount,
  SUM(recorded_revenue_usd) AS recorded_revenue_usd,
  SAFE_DIVIDE(SUM(recorded_revenue_usd), SUM(orders_with_amount)) AS aov_known_amount_usd,
  SAFE_DIVIDE(SUM(orders_with_amount), SUM(verified_orders)) AS amount_completeness_rate
FROM mart_session_funnel;
```

### SQL 08. FUNNEL TABLE: ratios are 0..1; display as percentages downstream.

```sql
-- 08. FUNNEL TABLE: ratios are 0..1; display as percentages downstream.
WITH counts AS (
  SELECT COUNTIF(viewed) AS n1, COUNTIF(carted_after_view) AS n2,
         COUNTIF(checked_out_after_cart) AS n3, COUNTIF(purchased_in_order) AS n4
  FROM mart_session_funnel
), steps AS (
  SELECT 1 AS step, 'view_item' AS event, n1 AS sessions, n1 AS previous_sessions, n1 AS entrants FROM counts
  UNION ALL SELECT 2, 'add_to_cart', n2, n1, n1 FROM counts
  UNION ALL SELECT 3, 'begin_checkout', n3, n2, n1 FROM counts
  UNION ALL SELECT 4, 'purchase', n4, n3, n1 FROM counts
)
SELECT '08_funnel_steps' AS result_set, *,
  SAFE_DIVIDE(sessions, previous_sessions) AS step_conversion_rate,
  SAFE_DIVIDE(sessions, entrants) AS entry_conversion_rate,
  IF(step = 1, NULL, previous_sessions - sessions) AS dropoff_sessions,
  IF(step = 1, NULL, 1 - SAFE_DIVIDE(sessions, previous_sessions)) AS dropoff_rate
FROM steps ORDER BY step;
```

### SQL 09. DEVICE COMPARISON: Wilson interval describes binomial uncertainty only.

```sql
-- 09. DEVICE COMPARISON: Wilson interval describes binomial uncertainty only.
-- Repeated sessions from the same user are dependent; this is not an A/B result.
WITH g AS (
  SELECT device_category, COUNT(*) AS sessions,
    COUNTIF(viewed) AS entrants, COUNTIF(purchased_in_order) AS completions,
    COUNTIF(verified_orders > 0) AS verified_buying_sessions
  FROM mart_session_funnel GROUP BY device_category
), rates AS (
  SELECT *, SAFE_DIVIDE(completions, entrants) AS rate,
    SAFE_DIVIDE(verified_buying_sessions, sessions) AS verified_order_session_rate
  FROM g
)
SELECT '09_device_conversion' AS result_set, *,
  SAFE_DIVIDE(rate + 3.8416 / (2*entrants)
    - 1.96*SQRT(SAFE_DIVIDE(rate*(1-rate), entrants) + SAFE_DIVIDE(3.8416, 4*entrants*entrants)),
    1 + SAFE_DIVIDE(3.8416, entrants)) AS wilson_lower_95,
  SAFE_DIVIDE(rate + 3.8416 / (2*entrants)
    + 1.96*SQRT(SAFE_DIVIDE(rate*(1-rate), entrants) + SAFE_DIVIDE(3.8416, 4*entrants*entrants)),
    1 + SAFE_DIVIDE(3.8416, entrants)) AS wilson_upper_95
FROM rates
WHERE entrants >= 100
ORDER BY entrants DESC;
```

### SQL 10. ACQUISITION SOURCE: traffic_source is FIRST-USER source, not session attribution.

```sql
-- 10. ACQUISITION SOURCE: traffic_source is FIRST-USER source, not session attribution.
SELECT '10_first_user_acquisition' AS result_set,
  first_user_source, first_user_medium, COUNT(*) AS sessions,
  COUNTIF(viewed) AS entrants, COUNTIF(purchased_in_order) AS funnel_completions,
  SAFE_DIVIDE(COUNTIF(purchased_in_order), COUNTIF(viewed)) AS entry_conversion_rate,
  SUM(verified_orders) AS verified_orders, SUM(recorded_revenue_usd) AS recorded_revenue_usd
FROM mart_session_funnel
GROUP BY first_user_source, first_user_medium
HAVING COUNTIF(viewed) >= 100
ORDER BY entrants DESC;
```

### SQL 11. DAILY TREND: cohort date = first observed event_date, not purchase date.

```sql
-- 11. DAILY TREND: cohort date = first observed event_date, not purchase date.
WITH daily AS (
  SELECT cohort_date, COUNT(*) AS sessions, COUNTIF(viewed) AS entrants,
    COUNTIF(purchased_in_order) AS completions, SUM(recorded_revenue_usd) AS recorded_revenue_usd
  FROM mart_session_funnel GROUP BY cohort_date
), calendar AS (
  SELECT day AS cohort_date FROM UNNEST(GENERATE_DATE_ARRAY(cohort_start, cohort_end)) AS day
), filled AS (
  SELECT c.cohort_date, COALESCE(d.sessions,0) AS sessions,
    COALESCE(d.entrants,0) AS entrants, COALESCE(d.completions,0) AS completions,
    d.recorded_revenue_usd
  FROM calendar AS c LEFT JOIN daily AS d USING (cohort_date)
)
SELECT '11_daily_trend' AS result_set, *,
  COUNT(*) OVER (ORDER BY cohort_date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS calendar_days_in_window,
  SAFE_DIVIDE(completions, entrants) AS daily_conversion,
  SAFE_DIVIDE(
    SUM(completions) OVER (ORDER BY cohort_date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW),
    SUM(entrants) OVER (ORDER BY cohort_date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW)
  ) AS trailing_7d_weighted_conversion,
  LAG(SAFE_DIVIDE(completions, entrants), 7) OVER (ORDER BY cohort_date) AS prior_week_daily_conversion
FROM filled ORDER BY cohort_date;
```

### SQL 12. TIME TO PURCHASE: successful ordered sessions only (selection explicitly stated).

```sql
-- 12. TIME TO PURCHASE: successful ordered sessions only (selection explicitly stated).
SELECT '12_time_to_purchase' AS result_set,
  APPROX_QUANTILES(view_to_purchase_seconds,100)[OFFSET(50)] AS median_seconds,
  APPROX_QUANTILES(view_to_purchase_seconds,100)[OFFSET(90)] AS p90_seconds,
  COUNT(*) AS completed_funnel_sessions
FROM mart_session_funnel WHERE purchased_in_order;
```

### SQL 13. PRODUCT EXPOSURE: observational event/item statistics, not a same-item funnel.

```sql
-- 13. PRODUCT EXPOSURE: observational event/item statistics, not a same-item funnel.
-- Deduplicate membership at session x item x event_name after UNNEST(items).
WITH memberships AS (
  SELECT DISTINCT e.session_key, i.item_id, e.event_name
  FROM valid_events AS e
  JOIN fct_sessions AS s USING (session_key)
  CROSS JOIN UNNEST(e.items) AS i
  WHERE e.event_name IN ('view_item','add_to_cart')
    AND i.item_id IS NOT NULL AND i.item_id NOT IN ('','(not set)','<Other>')
)
SELECT '13_product_exposure' AS result_set, item_id,
  COUNTIF(event_name = 'view_item') AS viewing_sessions,
  COUNTIF(event_name = 'add_to_cart') AS adding_sessions
FROM memberships GROUP BY item_id
HAVING COUNTIF(event_name = 'view_item') >= 100
ORDER BY viewing_sessions DESC;
```

### SQL 14. SAME-TIMESTAMP QUALITY: do not invent within-batch ordering.

```sql
-- 14. SAME-TIMESTAMP QUALITY: do not invent within-batch ordering.
SELECT '14_timestamp_ties' AS result_set,
  COUNT(*) AS session_timestamp_groups,
  COUNTIF(step_names > 1) AS groups_with_multiple_funnel_steps
FROM (
  SELECT session_key, event_ts_us, COUNT(DISTINCT event_name) AS step_names
  FROM valid_events JOIN fct_sessions USING (session_key)
  WHERE event_name IN ('view_item','add_to_cart','begin_checkout','purchase')
  GROUP BY session_key, event_ts_us
);
```

### SQL 15. EXPORT: use this cohort/session table for downstream plots and audit.

```sql
-- 15. EXPORT: use this cohort/session table for downstream plots and audit.
SELECT '15_session_funnel_export' AS result_set, * FROM mart_session_funnel;

-- Sensitivity: rerun the full script with strict_order = FALSE; compare section 08.
-- Do not treat the difference as proven recovered conversions; order is ambiguous.
```

## 12. Chạy kiểm thử logic cục bộ

Bộ kiểm thử đi kèm chỉ dùng Python tiêu chuẩn và SQLite. Không cần tài khoản cloud để chạy phần này. Bản SQLite kiểm chứng thuật toán phễu, không kiểm chứng dialect GoogleSQL hoặc chất lượng dataset GA4.

```shell
python -m unittest discover -s tests -v
```

Kết quả đã ghi nhận ngày 28/10/2026: **13 tests — OK**. Các kiểm thử ngẫu nhiên dùng seed 42 để tái lập. Bộ mã và test được cung cấp trong bản ZIP đi kèm nếu giao diện cho phép đính kèm; mọi SQL chính đã có đầy đủ phía trên.

## 13. Giới hạn và tiêu chí hoàn thành

- Dữ liệu đã làm nhiễu và có thể không nhất quán nội bộ; kết luận chỉ áp dụng cho sample được kiểm tra.
- Phễu cấp phiên không đo hành trình nhiều phiên hoặc cùng sản phẩm; mất cookie / consent có thể làm sai coverage.
- Sự kiện cùng timestamp không có thứ tự chắc chắn trong dataset mẫu này.
- Không có nhóm ngẫu nhiên, chi phí quảng cáo, giá vốn hoặc tồn kho để tính uplift nhân quả, CAC, ROAS hoặc lợi nhuận thực.
- Khoảng Wilson trong truy vấn chỉ mô tả bất định nhị thức. Phiên của cùng user có phụ thuộc; không dùng để tuyên bố A/B significant.
- Chỉ coi phân tích dữ liệu nguồn hoàn thành sau khi chạy BigQuery, qua quality checks, lưu kết quả và thay bảng chờ bằng bằng chứng thực.
- Chỉ ghi trên CV là dự án đã hoàn thành sau khi tự chạy và giải thích được metric, grain, session key và chính sách funnel.

## 14. Kiến thức bạn cần làm chủ

- SQL: CTE, JOIN, aggregate có điều kiện, window functions, ROW_NUMBER, ARRAY / STRUCT và UNNEST.
- Product analytics: session, closed-entry funnel, conversion / drop-off, cohort date và acquisition source.
- Data quality: missing keys, duplicate parameters, transaction conflicts, reconciliation và boundary censoring.
- Thống kê: chênh lệch điểm phần trăm, độ bất định và khác biệt giữa tương quan với tác động nhân quả.
- Hiệu năng: lọc _TABLE_SUFFIX bằng hằng, chỉ lấy trường cần dùng, tách grain trước khi JOIN và ghi bytes processed.

## 15. Nguồn tham khảo chính thức

- [Dataset và giới hạn sample](https://developers.google.com/analytics/bigquery/web-ecommerce-demo-dataset)
- [Schema BigQuery export](https://support.google.com/analytics/answer/7029846?hl=en)
- [Query cookbook cơ bản và lưu ý batch ordering fields](https://developers.google.com/analytics/bigquery/basic-queries)
- [Advanced queries](https://developers.google.com/analytics/bigquery/advanced-queries)
- [BigQuery Sandbox](https://cloud.google.com/bigquery/docs/sandbox)

**KẾT THÚC — GA4 SQL PORTFOLIO v1.0 / 28-10-2026.** Phần triển khai và kiểm thử logic đã có; kết quả trên dữ liệu nguồn còn chờ BigQuery. Không có metric kinh doanh giả trong trang này.
