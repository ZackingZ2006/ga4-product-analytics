# Kiểm tra bổ sung — BigQuery 29/10/2026

- Job: `job_W3AZbdBxIRDZATHSpY5fJ9HkPZOM`, US, thực thi thành công. SQL: `sql/03_diagnostics_segments.sql`; dữ liệu kết quả: `results/bigquery_strict/16_diagnostics_segments.json` và `.csv`. Cùng cohort và phễu strict của truy vấn chính.
- Desktop: 2.949/8.250 phiên giỏ đến checkout (35,75%); mobile: 2.085/5.732 (36,37%). Tổng 3 thiết bị khớp 14.284 phiên giỏ và 5.143 checkout.
- Nguồn đầu tiên: google / organic 1.399/4.093 (34,18%); direct / none 1.187/3.311 (35,85%). Không phải attribution của phiên.
- Trong 9.141 phiên có cart theo phễu nhưng không có checkout theo thứ tự chặt, 554 vẫn có checkout tại thời điểm khác hoặc bằng timestamp trong cùng phiên. Trong 4.817 phiên có purchase bất kỳ, 3 không có checkout bất kỳ trong phiên. Không thể khẳng định thiếu tracking hay rời bỏ giỏ từ các dấu hiệu này.
- Dữ liệu mẫu đã làm nhiễu; các so sánh là mô tả, không xác định nguyên nhân. Một lượt purchase event không phải đơn hàng đã xác thực.
