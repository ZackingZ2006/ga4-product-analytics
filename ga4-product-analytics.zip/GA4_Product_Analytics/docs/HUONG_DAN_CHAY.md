# Hướng dẫn chạy GA4 Product Analytics

## 1. Bạn đang có gì?

Bạn có các truy vấn GoogleSQL, kiểm thử bằng Python/SQLite và công cụ dựng báo cáo. Các truy vấn chưa chạy trên BigQuery; chưa có KPI thật từ GA4. **Không lấy số trong `tests/fixtures` làm kết quả portfolio.**

Trang Notion có thêm mục lục, tóm tắt và checklist bạn đã chỉnh sửa. Mục 08b của trang đã được đưa vào file SQL chính trong bộ tải về. Mục 16 được tách thành `02_optional_persist.sql`.

## 2. Chạy kiểm thử không cần BigQuery

Giải nén ZIP, mở terminal trong thư mục `GA4_Product_Analytics`, cài Python 3.9+ rồi chạy:

```powershell
python -m unittest discover -s tests -v
python scripts/build_report.py --input tests/fixtures/strict --weak tests/fixtures/weak --mode fixture --output demo_report
```

`demo_report/bao_cao.md` và `demo_report/funnel.svg` dùng dữ liệu giả lập, có nhãn nổi bật. Kiểm thử này không kết nối tới BigQuery.

## 3. Chuẩn bị BigQuery

Theo [hướng dẫn chính thức của Google](https://developers.google.com/analytics/bigquery/web-ecommerce-demo-dataset), bạn cần một Google Cloud project có BigQuery. BigQuery Sandbox hoặc mức miễn phí có giới hạn có thể dùng để khám phá. Đăng nhập, tạo project và xử lý điều khoản bằng tài khoản của bạn.

Trong BigQuery SQL workspace, chọn **GoogleSQL**. Đặt địa điểm xử lý `US` khi cần chọn, phù hợp vị trí dataset. Xem thông báo giới hạn, quyền và lượng dữ liệu dự kiến trên giao diện của bạn.

## 4. Kiểm tra schema và lượng dữ liệu

1. Mở `sql/00_profile.sql` và chạy kiểm tra schema cùng hai ngày mẫu. Lưu kết quả và lỗi nếu có.
2. Dùng **validation/dry run** trên `sql/00_estimate_scan.sql` để ước tính phần đọc bảng nguồn của bước staging, không nhấn Run chỉ để xem ước tính. File này chỉ có SELECT và tham chiếu cùng các trường, khoảng ngày với staging.
3. `00_estimate_scan.sql` không ước tính toàn bộ xử lý bảng tạm. Theo [tài liệu Google](https://docs.cloud.google.com/bigquery/docs/multi-statement-queries), dry run không hỗ trợ `CREATE TEMP TABLE` và không xác thực toàn bộ câu lệnh sau đó. Ước tính không phải cam kết chi phí.

## 5. Chạy và lưu kết quả

1. Chạy toàn bộ `sql/01_ga4_funnel.sql` trong **một** multi-statement script. Mặc định `strict_order = TRUE`. Script đọc 92 bảng ngày nguồn một lần vào bảng tạm; đổi riêng `cohort_start` hay `cohort_end` không giảm dải đọc nguồn.
2. Các `ASSERT` ở mục 06 phải qua; nếu lỗi, lưu thông báo, sửa và chạy lại trước khi dùng KPI. Mục 02–04 giúp xác định dữ liệu bị loại và giao dịch cần kiểm tra.
3. Trong Google Cloud Console, xem kết quả từng câu lệnh của multi-statement job. Google cũng cho phép liệt kê các child job theo `parentJobId` rồi lấy kết quả từng job qua API. Lưu các CSV đúng tên:

```text
results/strict/07_kpi_overview.csv
results/strict/08_funnel_steps.csv
results/strict/08b_funnel_by_device.csv
```

4. Ghi lại project, job ID, ngày chạy, vùng, tham số, phiên bản SQL, lượng byte và cảnh báo. Đối chiếu loại trừ, số phiên, số đơn và doanh thu.
5. Muốn so sánh timestamp cùng lúc, chạy lại đầy đủ script với `strict_order = FALSE` và lưu ba CSV vào `results/weak/`. Hai lần chạy phải có cùng nguồn và tham số cohort; kiểm tra theo job record. Chênh lệch phản ánh độ nhạy, không xác định được thứ tự thật.

## 6. Lưu bảng mart nếu cần

Các TEMP TABLE thuộc script, vì vậy `sql/02_optional_persist.sql` cần được nối vào **cuối** script chính trước khi bấm chạy, cùng một lần chạy. Thay `YOUR_PROJECT` bằng project ID và chọn tên bảng **mới**. Khối này dùng `CREATE TABLE`, báo lỗi nếu tên đã tồn tại; nó không thay thế bảng cũ. Tạo dataset/bảng là thay đổi trong Cloud project và có thể phát sinh lưu trữ theo chính sách tài khoản. Sandbox có giới hạn và thời hạn tồn tại bảng theo tài liệu Google.

Mục 16 cũ trên Notion có `CREATE OR REPLACE TABLE`, có thể ghi đè bảng cùng tên. Chỉ sử dụng khi bạn thực sự muốn thay thế dữ liệu.

## 7. Tạo báo cáo từ CSV thật

```powershell
python scripts/build_report.py --input results/strict --weak results/weak --mode source --job-id TEN_JOB_ID --output reports/strict
```

Bỏ `--weak results/weak` nếu chưa chạy chính sách weak. Thay `TEN_JOB_ID` bằng job ID thực. Script kiểm tra thứ tự bước, số phiên giảm dần, mẫu số, tỷ lệ và tổng theo thiết bị; xuất `bao_cao.md`, `funnel.svg`, `report_manifest.json`. Job ID chỉ được ghi lại theo đầu vào, **không được công cụ xác thực từ xa**. Đối chiếu hai job và nguồn dữ liệu trước khi diễn giải.

Nếu có lỗi, lưu lỗi nguyên văn; không chỉnh số CSV để ép kiểm tra qua. Khi đã có kết quả thực và qua đối soát, cập nhật Notion với số liệu, kết luận và hạn chế.
