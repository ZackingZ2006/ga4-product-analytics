# Kết quả thực thi BigQuery — 29/10/2026

Nguồn: `bigquery-public-data.ga4_obfuscated_sample_ecommerce.events_*`; quét 01/11/2020–31/01/2021. Phiên được chọn theo ngày sự kiện đầu tiên 02/11/2020–30/01/2021 và loại phiên chạm hai ngày biên. Đơn vị là phiên `(user_pseudo_id, ga_session_id)`, không phải người hay giao dịch. Phễu là view_item → add_to_cart → begin_checkout → purchase theo cùng phiên; sản phẩm ở các bước có thể khác nhau.

- BigQuery Sandbox project: `triple-ranger-513123-c6`, location US.
- Job strict: `job_azoK8yFb8_Va3Fc7oapUVR52kyoB`, hoàn tất thành công; toàn bộ 12 ASSERT trong script qua.
- Job weak: `job_8ud3qwdcTahDSDAW0PHNeC8Hxrmj`, chạy tới mục 08b thành công, giữ cùng cohort; thay `strict_order` thành FALSE. Tên cột `strict_funnel_purchase_sessions` ở 07 vẫn là tên gốc của SQL, nhưng ở file weak biểu thị kết quả weak.
- SELECT ước lượng đọc nguồn: 2,62 GB; đây không phải tổng dung lượng xử lý của multi-statement script. Staging thực tế hiển thị 2,09 GB; các câu tiếp theo xử lý thêm bảng tạm.
- BigQuery hiển thị 4.295.584 dòng sự kiện; 360.129 phiên ứng viên; 354.655 phiên thỏa điều kiện; 5.474 phiên chạm biên. 5.272 phiên ứng viên thiếu session_start, vẫn được đưa vào nếu đủ điều kiện; toàn nguồn có 0 sự kiện không có khóa phiên hợp lệ theo quy tắc của script.

| Bước | Phiên strict | Chuyển đổi từ bước trước | Tỷ lệ từ view |
|---|---:|---:|---:|
| view_item | 75.911 | 100% | 100% |
| add_to_cart | 14.284 | 18,82% | 18,82% |
| begin_checkout | 5.143 | 36,01% | 6,78% |
| purchase event | 2.762 | 53,70% | 3,64% |

Mất 61.627 phiên giữa view và cart, tương đương 81,18% số phiên vào phễu. Đây là không ghi nhận đủ bước tiếp theo trong cùng phiên, không chứng minh người dùng rời site hoặc nguyên nhân. Có thể ưu tiên rà soát trang sản phẩm, giá, nút thêm giỏ và chất lượng tracking, sau đó thử nghiệm A/B; không cam kết tác động khi chưa thử nghiệm.

Theo thiết bị: desktop 1.558/44.183 = 3,53%; mobile 1.144/30.050 = 3,81%; tablet 60/1.678 = 3,58%. Các tỷ lệ mang tính mô tả, khác biệt không chứng minh thiết bị gây ra chênh lệch.

Chất lượng: 906/5.692 purchase event trên toàn nguồn thiếu transaction ID (15,92%). Có 4.451 ID giao dịch khác nhau, 326 ID lặp, 15 ID bị cách ly do xung đột; 4.436 ID không bị cách ly được gán vào phiên đủ điều kiện. `purchase` trong phễu có thể không có ID; không coi 2.762 là số đơn xác thực. Tổng giá trị ghi nhận 306.678 USD là số trong tập mẫu đã làm nhiễu, không đại diện doanh thu thật.

Kiểm tra độ nhạy: strict có 2.762 phiên purchase (3,64% số phiên view); weak có 2.818 phiên (3,71%). Chênh 56 phiên chỉ thể hiện độ nhạy quy tắc cho sự kiện trùng thời điểm, không xác nhận thứ tự thực. Có 24.978 nhóm session/timestamp chứa hơn một loại sự kiện phễu. `event_timestamp` là thời điểm Analytics nhận sự kiện; dữ liệu đã làm nhiễu, không đầy đủ và có thể không nhất quán. `traffic_source` là nguồn thu hút ban đầu của người dùng, không phải attribution của phiên.

Tệp JSON được sao chép từ tab JSON của từng child job BigQuery; CSV là bản chuyển đổi từ JSON. `reports/.../report_manifest.json` ghi `remote_job_verified: false` vì công cụ dựng báo cáo không tự gọi BigQuery; trạng thái job đã được kiểm tra trực tiếp trên giao diện. Các bảng tạm và kết quả job có thời hạn lưu; bộ kết quả tổng hợp được lưu cục bộ trong thư mục `results`.
