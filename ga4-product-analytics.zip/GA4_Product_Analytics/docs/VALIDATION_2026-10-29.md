# Nhật ký kiểm tra — 29/10/2026

Trang bạn đã sửa có thêm tóm tắt, mục lục, sơ đồ luồng, truy vấn 08b so sánh bước phễu theo thiết bị, khối 16 lưu bảng và checklist. Những nội dung này được giữ lại trên Notion. Đã đưa 08b vào file SQL chính; khối lưu bảng được cung cấp riêng theo cách không ghi đè bảng sẵn có.

## Kiểm thử thực hiện

- 13 kiểm thử phễu và chuẩn hóa với SQLite/Python, gồm 500 luồng ngẫu nhiên ở cả hai quy tắc timestamp.
- 5 kiểm thử trình dựng báo cáo: nhãn dữ liệu giả lập, yêu cầu job ID cho mode source, phát hiện phễu tăng bất hợp lý, phát hiện tỷ lệ không khớp và so sánh strict/weak.
- Tổng: **18 kiểm thử qua** trên Python 3.13.
- SQLGlot phân tích cú pháp GoogleSQL các câu lệnh được hỗ trợ; các câu `ASSERT` được loại riêng trước khi parse vì parser không hỗ trợ chúng. Parser bên thứ ba không thay thế BigQuery dry-run hoặc thực thi.
- Báo cáo demo từ fixture có nhãn **DỮ LIỆU KIỂM THỬ GIẢ LẬP — KHÔNG PHẢI KẾT QUẢ GA4**.

## Chưa hoàn thành

Chưa có Google Cloud project của bạn, do đó chưa chạy preflight, dry run hoặc script trên BigQuery. Không có kết quả KPI từ dataset nguồn; SQL phải được xác minh trên BigQuery trước khi coi bài phân tích hoàn tất. Công cụ tạo báo cáo không xác minh job ID từ xa.

`cohort_date` trong script là **ngày event_date nhỏ nhất quan sát trong phiên**. Không bảo đảm đó là ngày của sự kiện được nhận sớm nhất theo event_timestamp khi có sự kiện đến trễ. `event_timestamp` trong GA4 là thời điểm Google Analytics nhận sự kiện, không nhất thiết là thời điểm xảy ra trên thiết bị. Cần xét rủi ro này khi diễn giải thứ tự.
