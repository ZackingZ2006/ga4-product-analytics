"""Analyze the independently published, filtered GA4 event extract with SQLite.

The CSV is NOT the original GA4 export; see docs/PHAN_TICH_DU_LIEU_TRICH_XUAT.md.
Run: python scripts/analyze_external_extract.py path/to/extract.csv path/to/output
"""
import collections
import csv
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import sys

EXPECTED = '4ce499c70639bf5c9bd8ec0f9f88b46bcb408eadc67f9209ceb3fa37193a57e9'
EVENTS = ('view_item', 'add_to_cart', 'begin_checkout', 'purchase')


def main(src, out):
    src, out = Path(src), Path(out)
    out.mkdir(parents=True, exist_ok=True)
    with src.open('rb') as f:
        sha = hashlib.file_digest(f, 'sha256').hexdigest()
    if sha != EXPECTED:
        raise ValueError('Unexpected input SHA256; inspect provenance before proceeding')
    con = sqlite3.connect(':memory:')
    con.execute('CREATE TABLE events (session TEXT, ts TEXT, name TEXT, device TEXT)')
    with src.open('r', encoding='utf-8', newline='') as f:
        rows = csv.DictReader(f)
        required = {'user_session_id', 'event_timestamp', 'event_name', 'device_category'}
        if not required.issubset(rows.fieldnames or []):
            raise ValueError('Missing expected columns')
        def events():
            for r in rows:
                ts = r['event_timestamp']
                match = re.fullmatch(r'(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)(?:\.(\d{1,6}))? UTC', ts)
                if not match or not r['user_session_id']:
                    raise ValueError(f'Unexpected timestamp or session: {ts!r}')
                ts = match[1] + '.' + (match[2] or '').ljust(6, '0')
                yield (r['user_session_id'], ts, r['event_name'], r['device_category'] or 'Unknown')
        con.executemany('INSERT INTO events VALUES (?, ?, ?, ?)', events())
    con.execute('CREATE INDEX event_lookup ON events(session, name, ts)')
    quality = dict(con.execute('SELECT name, count(*) FROM events GROUP BY name ORDER BY name').fetchall())
    total_rows = con.execute('SELECT count(*) FROM events').fetchone()[0]
    con.executescript('''
        CREATE TEMP TABLE sessions AS
        SELECT session, MIN(ts) AS first_ts, MAX(ts) AS last_ts,
          CASE WHEN COUNT(DISTINCT device)=1 THEN MIN(device) ELSE 'Mixed' END AS device,
          COUNT(DISTINCT device) AS device_values
        FROM events GROUP BY session;
        CREATE INDEX sess_key ON sessions(session);
        CREATE TEMP TABLE eligible AS
        SELECT * FROM sessions WHERE substr(first_ts,1,10) >= '2020-11-02'
          AND substr(first_ts,1,10) <= '2021-01-30'
          AND substr(last_ts,1,10) < '2021-01-31';
        CREATE INDEX eligible_key ON eligible(session);
    ''')
    for mode, cmp in [('strict','>'), ('weak','>=')]:
        con.executescript(f'''
        DROP TABLE IF EXISTS funnel;
        CREATE TEMP TABLE funnel AS
        WITH v AS (
          SELECT s.session, s.device,
            (SELECT MIN(e.ts) FROM events e WHERE e.session=s.session AND e.name='view_item') AS v
          FROM eligible s
        ), a AS (
          SELECT *, (SELECT MIN(e.ts) FROM events e WHERE e.session=v.session AND e.name='add_to_cart' AND e.ts {cmp} v.v) AS a FROM v
        ), c AS (
          SELECT *, (SELECT MIN(e.ts) FROM events e WHERE e.session=a.session AND e.name='begin_checkout' AND e.ts {cmp} a.a) AS c FROM a
        )
        SELECT *, (SELECT MIN(e.ts) FROM events e WHERE e.session=c.session AND e.name='purchase' AND e.ts {cmp} c.c) AS p FROM c;
        ''')
        overall = list(con.execute('SELECT COUNT(*), COUNT(v), COUNT(a), COUNT(c), COUNT(p) FROM funnel').fetchone())
        devices = con.execute('SELECT device, COUNT(*), COUNT(v), COUNT(a), COUNT(c), COUNT(p) FROM funnel GROUP BY device ORDER BY COUNT(v) DESC').fetchall()
        assert all(overall[i] >= overall[i+1] for i in range(1,4))
        assert sum(row[2] for row in devices) == overall[1]
        with (out / f'funnel_{mode}.csv').open('w', encoding='utf-8', newline='') as f:
            w = csv.writer(f); w.writerow(['device','eligible_sessions','view_item','add_to_cart','begin_checkout','purchase']); w.writerows(devices)
        summary[mode] = {'counts': overall, 'by_device': devices}
    stats = con.execute('SELECT MIN(first_ts), MAX(last_ts), COUNT(*), SUM(device_values>1) FROM sessions').fetchone()
    eligible_n = con.execute('SELECT COUNT(*) FROM eligible').fetchone()[0]
    summary.update({'sha256': sha, 'event_rows': total_rows, 'events_by_name': quality,
                    'sessions_all': stats[2], 'min_utc': stats[0], 'max_utc': stats[1],
                    'device_conflict_sessions_all': stats[3], 'eligible_sessions': eligible_n})
    assert summary['weak']['counts'][1] == summary['strict']['counts'][1]
    assert all(a >= b for a, b in zip(summary['weak']['counts'],summary['strict']['counts']))
    (out/'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    print(json.dumps(summary, indent=2, ensure_ascii=False))


summary = {}
if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('Usage: python analyze_external_extract.py CSV OUTPUT_DIR')
    main(*sys.argv[1:])
